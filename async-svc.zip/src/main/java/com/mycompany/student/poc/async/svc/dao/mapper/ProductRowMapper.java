package com.mycompany.student.poc.async.svc.dao.mapper;

import com.mycompany.student.poc.async.svc.dao.entity.Product;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProductRowMapper implements RowMapper<Product> {
    public Product mapRow(java.sql.ResultSet rs, int rownum) throws SQLException {
        Product p = new Product();
        p.setId(rs.getLong("id"));
        p.setSalesforceId(rs.getString("salesforce_id"));
        p.setNetsuiteId(rs.getString("netsuite_id"));
        return p;
    }
}
