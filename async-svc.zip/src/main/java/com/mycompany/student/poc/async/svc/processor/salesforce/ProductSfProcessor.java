package com.mycompany.student.poc.async.svc.processor.salesforce;

import com.mycompany.student.poc.async.svc.config.AppConfig;
import com.mycompany.student.poc.async.svc.dao.entity.Product;
import com.mycompany.student.poc.async.svc.dao.mapper.ProductRowMapper;
import com.mycompany.student.poc.async.svc.util.NetSuiteTokenPassport;
import com.mycompany.student.poc.async.svc.util.OAuth1Request;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ProductSfProcessor {

    Logger logger = LoggerFactory.getLogger(ProductSfProcessor.class);

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private OAuth1Request oAuth1Request;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private NetSuiteTokenPassport netSuiteTokenPassport;

    public void findProductStatus(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getIn().getBody(Map.class);
        Message m = exchange.getIn();
        List<Product> ps = jdbcTemplate.query(appConfig.configById("select-product-by-sfid"), new ProductRowMapper(), ip.get("id"));
        if(ps == null || ps.isEmpty() || ps.get(0).getNetsuiteId() == null) {
            exchange.setProperty("netsuite-operation", "INSERT");
        } else {
            exchange.setProperty("netsuite-operation", "UPDATE");
            exchange.setProperty("DB-DATA", ps.get(0));
        }
    }

    public void updateNsProduct(String body, Exchange exchange) throws Exception {
        Message m = exchange.getIn();
        m.removeHeaders("*");
        Map ip = exchange.getIn().getBody(Map.class);
        StringBuffer url = new StringBuffer(appConfig.netsuiteUrl).append("/services/NetSuitePort_2021_1");
        Map<String, Object> c = netSuiteTokenPassport.getTokenPassport();
        String b = String.format(appConfig.configById("update-noninventory-saleitem"),
                appConfig.netsuiteRealm,
                appConfig.netsuiteConsumerKey,
                appConfig.netsuiteAccessToken,
                c.get("nonce"),
                c.get("timestamp"),
                "HMAC_SHA256",
                c.get("signature"),
                exchange.getProperty("DB-DATA", Product.class).getNetsuiteId(),
                ip.get("description"),
                ip.get("name"));


        m.setHeader("Content-Type", "text/xml;charset=UTF-8");
        m.setHeader("SOAPAction", "\"update\"");
        exchange.setProperty("serviceMethod", "POST");
        exchange.setProperty("serviceUrl", url);
        m.setBody(b);
    }

    public void createDBMap(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getProperty("INPUT-PAYLOAD", Map.class);
        Message m = exchange.getIn();
        String nfId = null;
        Map resp = (Map) ((Map)((Map)exchange.getIn().getBody(Map.class).get("Body")).get("addResponse")).get("writeResponse");
        if(resp != null && !resp.isEmpty() && resp.containsKey("baseRef")) {
            nfId = (String) ((Map)resp.get("baseRef")).get("internalId");
        }

        if(nfId == null) {
            throw new RuntimeException("Netsuite add product failed: " + exchange.getIn().getBody().toString());
        }

        jdbcTemplate.update(appConfig.configById("insert-product-db-map"), "sf", Calendar.getInstance().getTime(),
                ip.get("id"), nfId);

    }

    public void addNsProduct(String body, Exchange exchange) throws Exception {
        Message m = exchange.getIn();
        m.removeHeaders("*");
        Map ip = exchange.getIn().getBody(Map.class);
        StringBuffer url = new StringBuffer(appConfig.netsuiteUrl).append("/services/NetSuitePort_2021_1");
        Map<String, Object> c = netSuiteTokenPassport.getTokenPassport();
        String b = String.format(appConfig.configById("add-noninventory-saleitem"),
                appConfig.netsuiteRealm,
                appConfig.netsuiteConsumerKey,
                appConfig.netsuiteAccessToken,
                c.get("nonce"),
                c.get("timestamp"),
                "HMAC_SHA256",
                c.get("signature"),
                ip.get("description"),
                ip.get("name"),
                ip.get("name"));


        m.setHeader("Content-Type", "text/xml;charset=UTF-8");
        m.setHeader("SOAPAction", "\"add\"");
        exchange.setProperty("serviceMethod", "POST");
        exchange.setProperty("serviceUrl", url);
        m.setBody(b);
    }
}
