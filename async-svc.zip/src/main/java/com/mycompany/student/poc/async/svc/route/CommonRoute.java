package com.mycompany.student.poc.async.svc.route;

import com.mycompany.student.poc.async.svc.processor.CommonProcessor;
import com.mycompany.student.poc.async.svc.util.NetSuiteOAuth1Util;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.salesforce.SalesforceComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


@Component
public class CommonRoute extends RouteBuilder {

    @Autowired
    private SalesforceComponent salesforceComponent;
    @Autowired
    private NetSuiteOAuth1Util netSuiteOAuth1Util;

    @Override
    public void configure() throws Exception {
        getCamelContext().getGlobalOptions().put("CamelJacksonEnableTypeConverter", "true");
        getContext().addComponent("salesforceComponent", salesforceComponent);

        // REST API
        restConfiguration().component("servlet");

        from("direct:rest")
                .routeId("direct-rest")
                .toD("${exchangeProperty.serviceUrl}")
                .removeProperty("serviceUrl")
                .removeHeader(Exchange.HTTP_METHOD);

        from("direct:netsuite")
                .process(e -> {
                    try {
                        Response response = netSuiteOAuth1Util.makeApiRequest(e.getProperty("serviceMethod", String.class),
                                e.getProperty("serviceUrl", String.class), e.getIn().getBody(String.class));
                        Message m = e.getIn();
                        m.setHeader("status", response.code());
                        m.setBody(response.body().string());
                        m.setHeader("Content-Type", "application/json");
                        response.close();
                    } catch (IOException | NoSuchAlgorithmException | InvalidKeyException e1) {
                        e1.printStackTrace();
                        throw  e1;
                    }
                });

        // Platform Event
        //from("salesforceComponent:subscribe:{{salesforce.event.channel1}}")
                //.to("direct:processSaleforceEvent");

    }
}
