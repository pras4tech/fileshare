package com.mycompany.student.poc.async.svc.dao.entity;

public class Product {

    private Long id;
    private String salesforceId;
    private String netsuiteId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSalesforceId() {
        return salesforceId;
    }

    public void setSalesforceId(String salesforceId) {
        this.salesforceId = salesforceId;
    }

    public String getNetsuiteId() {
        return netsuiteId;
    }

    public void setNetsuiteId(String netsuiteId) {
        this.netsuiteId = netsuiteId;
    }
}
