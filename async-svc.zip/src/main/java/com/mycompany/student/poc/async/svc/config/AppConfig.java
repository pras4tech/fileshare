package com.mycompany.student.poc.async.svc.config;

import org.apache.camel.CamelContext;
import org.apache.camel.component.salesforce.AuthenticationType;
import org.apache.camel.component.salesforce.SalesforceComponent;
import org.apache.camel.component.salesforce.SalesforceEndpointConfig;
import org.apache.camel.component.salesforce.SalesforceLoginConfig;
import org.apache.camel.language.xpath.XPathBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Configuration
public class AppConfig {
    @Value("${salesforce.USERNAME_PASWORD.loginUrl}")
    private String loginUrl;

    @Value("${salesforce.USERNAME_PASWORD.clientId}")
    private String clientId;

    @Value("${salesforce.USERNAME_PASWORD.clientSecret}")
    private String clientSecret;

    @Value("${salesforce.USERNAME_PASWORD.userName}")
    private String userName;

    @Value("${salesforce.USERNAME_PASWORD.grant}")
    private String grant;

    @Value("${salesforce.USERNAME_PASWORD.apiVersion}")
    private String apiVersion;

    @Value("${salesforce.USERNAME_PASWORD.proxyHost}")
    private String proxyHost;

    @Value("${salesforce.USERNAME_PASWORD.proxyPort}")
    private Integer proxyPort;

    @Value("${netsuite.url}")
    public String netsuiteUrl;

    @Value("${netsuite.algorithm}")
    public String netsuiteAlgorithm;

    @Value("${netsuite.consumerKey}")
    public String netsuiteConsumerKey;

    @Value("${netsuite.consumerSecret}")
    public String netsuiteConsumerSecret;

    @Value("${netsuite.accessToken}")
    public String netsuiteAccessToken;

    @Value("${netsuite.tokenSecret}")
    public String netsuiteTokenSecret;

    @Value("${netsuite.realm}")
    public String netsuiteRealm;

    @Value("classpath:/application-config.xml")
    private Resource appConstants;

    @Autowired
    private CamelContext context;

    public SalesforceLoginConfig type2LoginConfig() {
        SalesforceLoginConfig s = new SalesforceLoginConfig();
        s.setLoginUrl(loginUrl);
        s.setClientId(clientId);
        s.setClientSecret(clientSecret);
        s.setType(AuthenticationType.USERNAME_PASSWORD);
        s.setUserName(userName);
        s.setPassword(grant);
        return s;
    }

    @Bean
    public SalesforceComponent salesforceComponent() {
        SalesforceComponent s = new SalesforceComponent();
        s.setLoginConfig(type2LoginConfig());
        SalesforceEndpointConfig e = new SalesforceEndpointConfig();
        e.setApiVersion(apiVersion);
        s.setConfig(e);
        //s.setHttpProxySecure(false);
        //s.setHttpProxyHost(proxyHost);
        //s.setHttpProxyPort(proxyPort);
        return s;
    }

    public String configById(String id) throws IOException {
        if(context.getRegistry().lookupByName("xmlConstConfig") == null) {
            context.getRegistry().bind("xmlConstConfig", getAppCont());
        }
        return XPathBuilder.xpath("/app-config/config-entry[contains(@id, '"+id+"')]").evaluate(context, context.getRegistry().lookupByName("xmlConstConfig"));
    }

    private String getAppCont() throws IOException {
        String result = "";
        try(InputStream is = appConstants.getInputStream()) {
            result = new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
        return result;
    }

}
