package com.mycompany.student.poc.async.svc.util;

import com.mycompany.student.poc.async.svc.config.AppConfig;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.core5.net.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;

@Component
public class OAuth1Request {

    @Autowired
    AppConfig appConfig;

    public String constructOAuth1Request() throws Exception {

        String nonce = generateNonce();
        String timestamp = generateTimestamp();

        // Collect OAuth parameters
        List<String> params = new ArrayList<>();
        params.add("oauth_consumer_key=" + appConfig.netsuiteConsumerKey);
        params.add("oauth_nonce=" + nonce);
        params.add("oauth_signature_method=HMAC-SHA1");
        params.add("oauth_timestamp=" + timestamp);
        params.add("oauth_token=" + appConfig.netsuiteAccessToken);
        params.add("oauth_version=1.0");

        // Sort parameters alphabetically
        Collections.sort(params);

        // Construct base string
        String baseString = "GET&" + URLEncoder.encode(appConfig.netsuiteUrl, "UTF-8") + "&" + URLEncoder.encode(String.join("&", params), "UTF-8");

        // Generate signing key
        String signingKey = URLEncoder.encode(appConfig.netsuiteConsumerSecret, "UTF-8") + "&" + URLEncoder.encode(appConfig.netsuiteTokenSecret, "UTF-8");

        // Generate signature
        String signature = generateSignature(baseString, signingKey);

        // Build Authorization header
        String authorizationHeader = "OAuth " +
                "oauth_consumer_key=\"" + appConfig.netsuiteConsumerKey + "\", " +
                "oauth_nonce=\"" + nonce + "\", " +
                "realm=\"" + appConfig.netsuiteRealm + "\", " +
                "oauth_signature=\"" + URLEncoder.encode(signature, "UTF-8") + "\", " +
                "oauth_signature_method=\"HMAC_SHA256\", " +
                "oauth_timestamp=\"" + timestamp + "\", " +
                "oauth_token=\"" + appConfig.netsuiteAccessToken + "\", " +
                "oauth_version=\"1.0\"";

        // Create HttpGet request
        return authorizationHeader;
    }

    private String generateSignature(String data, String key) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeyException {
        SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), appConfig.netsuiteAlgorithm);
        Mac mac = Mac.getInstance(appConfig.netsuiteAlgorithm);
        mac.init(signingKey);
        byte[] rawHmac = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(rawHmac);
    }

    private String generateNonce() {
        Random random = new Random();
        return String.valueOf(Math.abs(random.nextLong()));
    }

    private String generateTimestamp() {
        return String.valueOf(System.currentTimeMillis() / 1000);
    }

}
