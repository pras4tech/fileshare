package com.mycompany.student.poc.async.svc.processor.netsuite;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mycompany.student.poc.async.svc.config.AppConfig;
import com.mycompany.student.poc.async.svc.dao.entity.Product;
import com.mycompany.student.poc.async.svc.dao.mapper.ProductRowMapper;
import com.mycompany.student.poc.async.svc.dto.GlobalSObject;
import com.mycompany.student.poc.async.svc.util.NetSuiteTokenPassport;
import com.mycompany.student.poc.async.svc.util.OAuth1Request;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.component.salesforce.api.dto.Attributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ProductNsProcessor {

    Logger logger = LoggerFactory.getLogger(ProductNsProcessor.class);

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public void findProductStatus(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getIn().getBody(Map.class);
        Message m = exchange.getIn();
        List<Product> ps = jdbcTemplate.query(appConfig.configById("select-product-by-nsid"), new ProductRowMapper(), ip.get("id"));
        if(ps == null || ps.isEmpty() || ps.get(0).getNetsuiteId() == null) {
            exchange.setProperty("netsuite-operation", "INSERT");
        } else {
            exchange.setProperty("netsuite-operation", "UPDATE");
            exchange.setProperty("DB-DATA", ps.get(0));
        }
    }

    public void getSfProduct(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getProperty("INPUT-PAYLOAD", Map.class);
        Message m = exchange.getIn();
        m.removeHeaders("*");
        StringBuffer salesforceUrl = new StringBuffer("salesforceComponent:getSObjectWithId?rawPayload=true&sObjectName=Product2&sObjectIdName=Id&sObjectIdValue=");

        salesforceUrl.append(exchange.getProperty("DB-DATA", Product.class).getSalesforceId());
        m.setBody(null);
        exchange.setProperty("serviceUrl", salesforceUrl.toString());
    }

    public void updateSfProduct(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getProperty("INPUT-PAYLOAD", Map.class);
        Message m = exchange.getIn();
        //Map b = new HashMap();
        //Map b = m.getBody(Map.class);
        m.removeHeaders("*");
        GlobalSObject o = new GlobalSObject();
        o.setId(exchange.getProperty("DB-DATA", Product.class).getSalesforceId());
        o.setName((String) ip.get("name"));
        o.setDescription((String) ip.get("description"));
        StringBuffer salesforceUrl = new StringBuffer("salesforceComponent:upsertSObject?rawPayload=true&sObjectName=Product2&sObjectIdName=Id&sObjectIdValue=");
        salesforceUrl.append(exchange.getProperty("DB-DATA", Product.class).getSalesforceId());
        ObjectMapper om = new ObjectMapper();
        m.setBody(o);

        exchange.setProperty("serviceUrl", salesforceUrl.toString());
    }

    public void createDBMap(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getProperty("INPUT-PAYLOAD", Map.class);
        Message m = exchange.getIn();
        String sfId = null;
        Map resp = exchange.getIn().getBody(Map.class);
        if(resp != null && !resp.isEmpty() && resp.containsKey("id")) {
            sfId = (String) resp.get("id");
        }

        if(sfId == null) {
            throw new RuntimeException("Salesforce add product failed: " + exchange.getIn().getBody().toString());
        }

        jdbcTemplate.update(appConfig.configById("insert-product-db-map"), "sf", Calendar.getInstance().getTime(),
                sfId, ip.get("id"));

    }

    public void addSfProduct(String body, Exchange exchange) throws Exception {
        Map ip = exchange.getIn().getBody(Map.class);
        Message m = exchange.getIn();
        Map b = new HashMap();
        m.removeHeaders("*");
        StringBuffer salesforceUrl = new StringBuffer("salesforceComponent:createSObject?rawPayload=true&sObjectName=Product2");
        b.put("Name", ip.get("name"));
        b.put("Description", ip.get("description"));
        m.setBody(b);
        exchange.setProperty("serviceUrl", salesforceUrl.toString());
    }
}
