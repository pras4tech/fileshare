package com.mycompany.student.poc.async.svc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.camel.component.salesforce.api.dto.AbstractSObjectBase;

public class GlobalSObject extends AbstractSObjectBase {

    private String Description;

    @JsonProperty("Name")
    public String getDescription() {
        return Description;
    }

    @JsonProperty("Name")
    public void setDescription(String description) {
        Description = description;
    }
}
