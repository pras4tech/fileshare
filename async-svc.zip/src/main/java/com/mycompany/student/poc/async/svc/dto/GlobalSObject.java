package com.mycompany.student.poc.async.svc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.camel.component.salesforce.api.dto.AbstractSObjectBase;

public class GlobalSObject extends AbstractSObjectBase {

    private String Description;

    @JsonProperty("Description")
    public String getDescription() {
        return Description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        Description = description;
    }
}
