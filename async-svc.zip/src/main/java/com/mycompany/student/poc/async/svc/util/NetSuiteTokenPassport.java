package com.mycompany.student.poc.async.svc.util;

import com.mycompany.student.poc.async.svc.config.AppConfig;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

@Component
public class NetSuiteTokenPassport {

    private static final String OAUTH_VERSION = "1.0";
    private static final String OAUTH_SIGNATURE_METHOD = "HMAC_SHA256";

    @Autowired
    private AppConfig appConfig;

    public Map<String, Object> getTokenPassport()
            throws NoSuchAlgorithmException, InvalidKeyException {
        Map<String, Object> tokens = new HashMap<>();
        long timestamp = System.currentTimeMillis() / 1000;
        tokens.put("timestamp", timestamp);
        String nonce = generateNonce();
        tokens.put("nonce", nonce);

        StringBuffer b = new StringBuffer(appConfig.netsuiteRealm).append("&").append(appConfig.netsuiteConsumerKey)
                .append("&").append(appConfig.netsuiteAccessToken)
                .append("&").append(nonce).append("&").append(timestamp);


        String signingKey = appConfig.netsuiteConsumerSecret + "&" + appConfig.netsuiteTokenSecret;
        String signature = generateSignature(b.toString(), signingKey);
        tokens.put("signature", signature);
        return tokens;
    }

    private String generateSignature(String baseString, String signingKey)
            throws NoSuchAlgorithmException, InvalidKeyException {
        SecretKeySpec keySpec = new SecretKeySpec(signingKey.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(keySpec);
        byte[] result = mac.doFinal(baseString.getBytes(StandardCharsets.UTF_8));
        return new String(Base64.encodeBase64(result), StandardCharsets.UTF_8);
    }

    private String generateNonce() {
        Random random = new Random();
        return String.valueOf(random.nextInt(100000000));
    }
}
