package com.mycompany.student.poc.async.svc.processor;

import com.mycompany.student.poc.async.svc.config.AppConfig;
import com.mycompany.student.poc.async.svc.util.OAuth1Request;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.component.http.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;
@Component
public class CommonProcessor {

    //@Autowired
    //private JdbcTemplate jdbcTemplate;

    public void process(String operation, String body, Exchange exchange) {
        String result = null; //jdbcTemplate.queryForObject("select CURRENT_USER", String.class);
        exchange.getIn().setBody(Map.of("status", "success", "db user", result, "message", "Hello. Welcome to Camel World!"));
    }

}
