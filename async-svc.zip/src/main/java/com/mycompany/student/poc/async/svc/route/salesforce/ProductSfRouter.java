package com.mycompany.student.poc.async.svc.route.salesforce;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mycompany.student.poc.async.svc.processor.salesforce.ProductSfProcessor;
import okhttp3.Response;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.salesforce.SalesforceComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class ProductSfRouter extends RouteBuilder {

    @Autowired
    private SalesforceComponent salesforceComponent;

    private ObjectMapper mapper = new ObjectMapper();

    @Override
    public void configure() throws Exception {

        rest().path("/api/salesforce/product2")
                .post()
                .to("direct:convertApiData");

        from("direct:convertApiData")
                .convertBodyTo(String.class)
                .process(e -> {
                    if(e.getIn().getBody(String.class).trim().startsWith("[")) {
                        e.getIn().setBody(mapper.readValue(e.getIn().getBody(String.class).trim(), List.class).get(0));
                    } else {
                        e.getIn().setBody(mapper.readValue(e.getIn().getBody(String.class).trim(), Map.class));
                    }
                })
                .to("direct:handleSalesforceData");

        from("direct:handleSalesforceData")
                .doTry()
                    .to("direct:processSalesforceData")
                .endDoTry()
                .doCatch(Exception.class)
                .process( e -> {
                            Exception ex = (Exception) e.getProperty(e.EXCEPTION_CAUGHT, Throwable.class);
                            e.getIn().setHeader("status", "500");
                            e.getIn().setBody(Map.of("status", "failed", "message", ex.getMessage()));
                            e.getIn().setHeader("Content-Type", "application/json");
                        }
                    )
                .marshal().json()
                .end();

        from("direct:processSalesforceData")
                .process( e -> {
                    Map b = e.getIn().getBody(Map.class);
                    e.setProperty("TRACE-ID", b.get("id"));
                    e.setProperty("INPUT-PAYLOAD", b);
                })
                .to("direct:validateSalesforceData")
                .log(LoggingLevel.INFO, "1. salesforce_out - ${exchangeProperty.TRACE-ID} - ${body}")
                .bean(ProductSfProcessor.class, "findProductStatus(${body}, *)")
                .choice()
                    .when(simple("${exchangeProperty.netsuite-operation} == 'INSERT'"))
                        .bean(ProductSfProcessor.class, "addNsProduct(${body}, *)")
                        .to("direct:rest")
                        .log(LoggingLevel.INFO, "2. salesforce_out - ${exchangeProperty.TRACE-ID} - INSERT - ${body}")
                        .to("xj:identity?transformDirection=XML2JSON")
                        .convertBodyTo(Map.class)
                        .bean(ProductSfProcessor.class, "createDBMap(${body}, *)")
                    .when(simple("${exchangeProperty.netsuite-operation} == 'UPDATE'"))
                        .bean(ProductSfProcessor.class, "updateNsProduct(${body}, *)")
                        .to("direct:rest")
                        .log(LoggingLevel.INFO, "2. salesforce_out - ${exchangeProperty.TRACE-ID} - UPDATE - ${body}")
                        .to("xj:identity?transformDirection=XML2JSON")
                        .convertBodyTo(Map.class)
                .endChoice()
                .end()
                .setHeader("Content-Type", constant("application/json"))
                .marshal().json();
                //.marshal().json(JsonLibrary.Jackson);

        from("direct:validateSalesforceData")
                .process( e -> {
                    Map b = e.getProperty("INPUT-PAYLOAD", Map.class);
                    if(!b.containsKey("id") || b.get("id") == null) {
                        throw new IllegalArgumentException("Invalid Product: " + b.toString());
                    }
                });
        //from("direct:processSaleforceEvent")
                //.to("direct:handleSalesforceData");
    }
}
