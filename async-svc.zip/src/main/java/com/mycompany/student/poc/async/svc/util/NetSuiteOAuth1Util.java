package com.mycompany.student.poc.async.svc.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.mycompany.student.poc.async.svc.config.AppConfig;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NetSuiteOAuth1Util {

    @Autowired
    AppConfig appConfig;

    private static final String OAUTH_VERSION = "1.0";
    private static final String OAUTH_SIGNATURE_METHOD = "HMAC-SHA256";

    public String generateOAuthHeader(String httpMethod, String url)
            throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        String nonce = generateNonce();
        String timestamp = String.valueOf(System.currentTimeMillis() / 1000);

        // TreeMap ensures parameters are sorted alphabetically
        Map<String, String> oauthParams = new TreeMap<>();
        oauthParams.put("oauth_consumer_key", appConfig.netsuiteConsumerKey);
        oauthParams.put("oauth_nonce", nonce);
        oauthParams.put("oauth_signature_method", OAUTH_SIGNATURE_METHOD);
        oauthParams.put("oauth_timestamp", timestamp);
        oauthParams.put("oauth_token", appConfig.netsuiteAccessToken);
        oauthParams.put("oauth_version", OAUTH_VERSION);

        String baseString = generateBaseString(httpMethod, url, oauthParams);
        String signingKey = URLEncoder.encode(appConfig.netsuiteConsumerSecret, "UTF-8") + "&" + URLEncoder.encode(appConfig.netsuiteTokenSecret, "UTF-8");
        String signature = generateSignature(baseString, signingKey);

        StringBuilder header = new StringBuilder("OAuth realm=\"" + appConfig.netsuiteRealm + "\",");
        header.append("oauth_consumer_key=\"").append(appConfig.netsuiteConsumerKey).append("\",");
        header.append("oauth_token=\"").append(appConfig.netsuiteAccessToken).append("\",");
        header.append("oauth_nonce=\"").append(nonce).append("\",");
        header.append("oauth_timestamp=\"").append(timestamp).append("\",");
        header.append("oauth_signature_method=\"").append(OAUTH_SIGNATURE_METHOD).append("\",");
        header.append("oauth_version=\"").append(OAUTH_VERSION).append("\",");
        header.append("oauth_signature=\"").append(URLEncoder.encode(signature, "UTF-8")).append("\"");

        return header.toString();
    }

    private String generateBaseString(String httpMethod, String url, Map<String, String> params)
            throws UnsupportedEncodingException {
        StringBuilder baseString = new StringBuilder();
        baseString.append(httpMethod.toUpperCase()).append("&");
        baseString.append(URLEncoder.encode(url, "UTF-8")).append("&");

        StringBuilder paramsString = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (!first) {
                paramsString.append("&");
            }
            paramsString.append(entry.getKey()).append("=").append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            first = false;
        }
        baseString.append(URLEncoder.encode(paramsString.toString(), "UTF-8"));

        return baseString.toString();
    }

    private String generateSignature(String baseString, String signingKey)
            throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        SecretKeySpec keySpec = new SecretKeySpec(signingKey.getBytes("UTF-8"), OAUTH_SIGNATURE_METHOD.replace("HMAC-", ""));
        //Mac mac = Mac.getInstance(OAUTH_SIGNATURE_METHOD.replace("HMAC-", ""));
        Mac mac = Mac.getInstance(appConfig.netsuiteAlgorithm);
        mac.init(keySpec);
        byte[] result = mac.doFinal(baseString.getBytes("UTF-8"));
        return Base64.getEncoder().encodeToString(result);
    }

    private String generateNonce() {
        Random random = new Random();
        return String.valueOf(Math.abs(random.nextLong()));
    }

    public Response makeApiRequest(String httpMethod, String url, String requestBodyJson)
            throws IOException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        OkHttpClient client = new OkHttpClient();
        String oauthHeader = generateOAuthHeader(httpMethod, url);

        Request.Builder requestBuilder = new Request.Builder()
                .url(url)
                .header("Authorization", oauthHeader)
                .header("Content-Type", "application/json")
                .header("Host", "8020976-sb1.suitetalk.api.netsuite.com")
                .header("User-Agent", "okhttp/4.9.3");

        if (httpMethod.equalsIgnoreCase("POST") || httpMethod.equalsIgnoreCase("PUT") || httpMethod.equalsIgnoreCase("PATCH")) {
            MediaType mediaType = MediaType.parse("application/json");
            RequestBody body = RequestBody.create(requestBodyJson, mediaType);
            requestBuilder.method(httpMethod, body);
        } else if (httpMethod.equalsIgnoreCase("DELETE")) {
            requestBuilder.delete();
        }

        Request request = requestBuilder.build();
        return client.newCall(request).execute();
    }
}
