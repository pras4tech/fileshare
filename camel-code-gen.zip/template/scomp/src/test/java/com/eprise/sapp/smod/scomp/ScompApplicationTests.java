package com.eprise.sapp.smod.scomp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScompApplicationTests {

	@Test
	void contextLoads() {
	}

}
