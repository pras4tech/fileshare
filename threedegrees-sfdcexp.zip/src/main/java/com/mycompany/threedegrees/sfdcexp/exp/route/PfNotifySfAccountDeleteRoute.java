package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class PfNotifySfAccountDeleteRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        // Global error handler
        onException(Exception.class)
            .process(exchange -> {
                Exception exception = exchange.getProperty(Exception.class.getName(), Exception.class);
                if (exception != null) {
                    exchange.getMessage().setBody("Error: " + exception.getMessage());
                } else {
                    exchange.getMessage().setBody("Unknown error occurred.");
                }
                exchange.getMessage().setHeader("Content-Type", "application/json");
            })
            .log("Global Error Handler: ${exception.message}")
            .handled(true);

        // Main route for pf-notify-sf-account-delete
        from("direct:pfNotifySfAccountDelete")
            .routeId("pf-notify-sf-account-delete")
            .log("Flow Started: pf-notify-sf-account-delete")
            .process(exchange -> {
                // Placeholder for setting variables equivalent to MuleSoft's DataWeave transformations
                exchange.setProperty("vRequestAttributes", Map.of(
                    "headers", Map.of(
                        "x-source", "SALESFORCE",
                        "x-transactionId", exchange.getIn().getHeader("transactionId"),
                        "x-msg-timestamp", java.time.Instant.now().toString(),
                        "correlationId", exchange.getIn().getHeader("correlationId"),
                        "sourceId", "SALESFORCE_EXP_API",
                        "destinationId", "TRANSACTION_DB_SYS_API",
                        "content-type", "application/json"
                    )
                ));
                exchange.setProperty("vObjectType", exchange.getIn().getHeader("objectType", String.class).toUpperCase());
                exchange.setProperty("vSalesforceId", exchange.getIn().getHeader("id", String.class));
                exchange.setProperty("vSyncPriority", exchange.getIn().getHeader("syncPriority", String.class));
            })
            .choice()
                .when(simple("${header.enableSyncForSalesforce} == '1'"))
                    .log("enableSyncForSalesforce is enabled")
                    .to("direct:fetchEnterpriseId")
                .otherwise()
                    .log("enableSyncForSalesforce is disabled")
                    .process(exchange -> {
                        exchange.getMessage().setBody(Map.of(
                            "code", 200,
                            "transactionId", exchange.getIn().getHeader("transactionId"),
                            "status", "IGNORED",
                            "response", Map.of(
                                "message", "Record will not be processed for syncing",
                                "description", "Syncing is ignored as enableSyncForSalesforce is disabled"
                            )
                        ));
                        exchange.getMessage().setHeader("Content-Type", "application/json");
                    })
            .end()
            .log("Flow Ended: pf-notify-sf-account-delete");

        // Sub-route to fetch enterprise ID
        from("direct:fetchEnterpriseId")
            .log("Fetching ENTERPRISE_ID from REF_ID")
            .process(exchange -> {
                Map<String, Map<String, String>> vRequestAttributes =
                        exchange.getProperty("vRequestAttributes", Map.class);
                exchange.getIn().getHeaders().clear();
                exchange.getIn().getHeaders().putAll(vRequestAttributes.get("headers"));
                exchange.getIn().getHeaders().put("CamelHttpMethod", "GET");
                exchange.getIn().getHeaders().put("client_id", "9a436565123e4843a96b589937d1f8b6");
                exchange.getIn().getHeaders().put("client_secret", "8734621471834306B799f6D1F380eE0b");
                exchange.setProperty("fetchEnterpriseIdUrl",
                        "https://transactiondb-sys-api-dev-kby5ju.1avcn3.usa-w2.cloudhub.io:443/api/REF_ID" +
                        "?sslContextParameters=#sslContextParameters&SALESFORCE_ID="
                        + exchange.getProperty("vSalesforceId") +"&OBJECT_TYPE="
                        + exchange.getProperty("vObjectType"));
            })
            .toD("${exchangeProperty.fetchEnterpriseIdUrl}")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
                .process(exc -> {
                    System.out.println("test");
                })
            .choice()
                .when(simple("${body['response'].isEmpty()} == false"))
                    .log("Record found in REF_ID table")
                    .to("direct:insertTransactionDetails")
                .otherwise()
                    .log("Record does not exist in REF_ID table")
                    .process(exchange -> {
                        exchange.getMessage().setBody(Map.of(
                            "code", 200,
                            "transactionId", exchange.getIn().getHeader("x-transactionId"),
                            "status", "SUCCESS",
                            "response", Map.of(
                                "message", "Record will not be processed for syncing",
                                "description", "Record does not exist in REF_ID table"
                            )
                        ));
                        exchange.getMessage().setHeader("Content-Type", "application/json");
                    })
            .end();

        // Sub-route to insert transaction details
        from("direct:insertTransactionDetails")
            .log("Inserting into TRANSACTION_DETAIL")
            .process(exchange -> {
                Map<String, Object> transactionDetails = Map.of(
                    "CORRELATION_ID", exchange.getIn().getHeader("correlationId"),
                    "OPERATION", "DELETE",
                    "SOURCE", "SALESFORCE",
                    "STATUS", "QUEUED",
                    "LAST_UPDATED_BY", "EXPERIENCE_API",
                    "ENTERPRISE_ID", exchange.getIn().getHeader("enterpriseId"),
                    "PRIORITY", exchange.getProperty("vSyncPriority", String.class),
                    "OBJECT_TYPE", "ACCOUNT",
                    "RETRY_COUNT", 0
                );
                exchange.getMessage().setBody(transactionDetails);
            })
            .toD("http4://transaction-db-sys-api/${header.transactionDetailsPath}?bridgeEndpoint=true")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
            .marshal().json()
            .log("Transaction details inserted successfully")
            .to("direct:callSyncProcess");

        // Sub-route to call SyncPrc API
        from("direct:callSyncProcess")
            .log("Calling SyncPrc to process record")
            .process(exchange -> {
                // Placeholder for processing before HTTP call
            })
            .toD("http4://sync-prc-api/${header.syncRecordsPath}?bridgeEndpoint=true")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
            .marshal().json()
            .log("Sync record response: ${body}")
            .process(exchange -> {
                exchange.getMessage().setBody(Map.of(
                    "code", 200,
                    "transactionId", exchange.getIn().getHeader("transactionId"),
                    "status", "SUCCESS",
                    "response", Map.of(
                        "message", "Request for delete notification has been submitted for validation and processing."
                    )
                ));
                exchange.getMessage().setHeader("Content-Type", "application/json");
            });
    }
}