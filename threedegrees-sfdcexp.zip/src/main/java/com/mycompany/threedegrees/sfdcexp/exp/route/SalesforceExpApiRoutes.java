package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class SalesforceExpApiRoutes extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        // Global error handler
        onException(Exception.class)
            .process(exchange -> {
                Exception exception = exchange.getProperty(Exception.class.getName(), Exception.class);
                if (exception != null) {
                    exchange.getMessage().setBody("Error: " + exception.getMessage());
                } else {
                    exchange.getMessage().setBody("Unknown error occurred.");
                }
                exchange.getMessage().setHeader("Content-Type", "application/json");
            })
            .log("Global Error Handler: ${exception.message}")
            .handled(true);

        // Define REST API
        rest()
            .path("/api")
            .consumes("application/json")
            .produces("application/json")
            .get("/notifyDelete")
                .to("direct:notifyDelete")
            .post("/orders")
                .to("direct:createOrder")
            .put("/orders")
                .to("direct:updateOrder")
            .delete("/orders")
                .to("direct:deleteOrder")
            .put("/invoices")
                .to("direct:updateInvoice");

        // Sub-route for notifyDelete (GET operation)
        from("direct:notifyDelete")
            .log("Executing notifyDelete operation...")
            .to("direct:pfNotifySfAccountDelete")
            .marshal().json();

        // Sub-route for creating an order
        from("direct:createOrder")
            .log("Creating order...")
            .process(exchange -> {
                // Placeholder process logic
                exchange.getMessage().setHeader("Content-Type", "application/json");
            })
            .toD("http4://example.com/orders")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
            .marshal().json();

        // Sub-route for updating an order
        from("direct:updateOrder")
            .log("Updating order...")
            .process(exchange -> {
                // Placeholder process logic
                exchange.getMessage().setHeader("Content-Type", "application/json");
            })
            .toD("http4://example.com/orders")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
            .marshal().json();

        // Sub-route for deleting an order
        from("direct:deleteOrder")
            .log("Deleting order...")
            .process(exchange -> {
                // Placeholder process logic
                exchange.getMessage().setHeader("Content-Type", "application/json");
            })
            .toD("http4://example.com/orders")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
            .marshal().json();

        // Sub-route for updating an invoice
        from("direct:updateInvoice")
            .log("Updating invoice...")
            .process(exchange -> {
                // Placeholder process logic
                exchange.getMessage().setHeader("Content-Type", "application/json");
            })
            .toD("http4://example.com/invoices")
            .convertBodyTo(String.class)
            .convertBodyTo(java.util.Map.class)
            .marshal().json();
    }
}