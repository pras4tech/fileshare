package com._3degrees.orders.salesforce.exp.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class CamelRoutes extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        // Global error handler
        onException(Exception.class)
                .process(e -> {
                    System.out.println("test");
                })
                .log("Global Error Handler: ${exception.message}")
                .handled(true)
                .to("log:error");

        // Define REST API
        rest()
                .path("/api")
                .consumes("application/json")
                .produces("application/json")
                .get("/notifyDelete")
                .to("direct:notifyDelete")
                .post("/orders")
                .to("direct:createOrder")
                .put("/orders")
                .to("direct:updateOrder")
                .delete("/orders")
                .to("direct:deleteOrder")
                .put("/invoices")
                .to("direct:updateInvoice");

        // Sub-route for notifyDelete (GET operation)
        from("direct:notifyDelete")
                .log("Executing notifyDelete operation...")
                .to("direct:pfNotifySfAccountDelete");

        // Sub-route for creating an order
        from("direct:createOrder")
                .log("Creating order...")
                .to("bean:orderService?method=createOrder");

        // Sub-route for updating an order
        from("direct:updateOrder")
                .log("Updating order...")
                .to("bean:orderService?method=updateOrder");

        // Sub-route for deleting an order
        from("direct:deleteOrder")
                .log("Deleting order...")
                .to("bean:orderService?method=deleteOrder");

        // Sub-route for updating an invoice
        from("direct:updateInvoice")
                .log("Updating invoice...")
                .to("bean:invoiceService?method=updateInvoice");
    }
}