package com._3degrees.orders.salesforce.exp.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class AccountService {

    public void setNotifyDeleteReq(Exchange exchange) {
        Map<String, String> headers = exchange.getProperty("vRequestAttributes", Map.class);
        headers.put("CamelHttpMethod", "GET");
        headers.put("client_id", "IwNbkemGEkJinvVWrAsUMvQC06GD+rs/7BP6EErFV1T56Nso49aVoQ==");
        headers.put("client_secret", "2G4GgxsJxpCuwW0Rb4oPvGVWYqtwr/eKnETLf/1D06cNovAYw+MLtA==");
        exchange.getIn().getHeaders().putAll(headers);
    }

}