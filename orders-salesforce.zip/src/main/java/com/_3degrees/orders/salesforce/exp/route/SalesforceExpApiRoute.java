package com._3degrees.orders.salesforce.exp.route;


import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.stereotype.Component;

@Component
public class SalesforceExpApiRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Route for /notifyDelete
        rest("/notifyDelete")
                .get()
                .description("Accepts the deletion notification for account record and deletes record if eligible for deletion.")
                .param()
                .name("id")
                .type(RestParamType.query)
                .description("Salesforce ID of the account")
                .required(true)
                .endParam()
                .param()
                .name("objectType")
                .type(RestParamType.query)
                .description("Type of object")
                .required(true)
                .endParam()
                .param()
                .name("updatedBy")
                .type(RestParamType.query)
                .description("Updated by user")
                .required(true)
                .endParam()
                .param()
                .name("syncPriority")
                .type(RestParamType.query)
                .description("Priority for processing this record")
                .required(false)
                .endParam()
                .to("direct:processNotifyDelete");

        from("direct:processNotifyDelete")
                .log("Processing notifyDelete request with id=${header.id}, objectType=${header.objectType}, updatedBy=${header.updatedBy}, syncPriority=${header.syncPriority}")
                .setBody(constant("{\"status\": \"success\", \"message\": \"Record processed successfully\"}"))
                .setHeader("Content-Type", constant("application/json"));

        // Route for /orders
        rest("/orders")
                .post()
                .description("Request for creating Order (and related child objects) in Netsuite")
                .type(String.class)
                .to("direct:createOrder")
                .put()
                .description("Request for updating Order (and related child objects) in Netsuite")
                .type(String.class)
                .to("direct:updateOrder")
                .delete()
                .description("Request for deleting Order (and related child objects) in Netsuite")
                .param()
                .name("orderNetsuiteId")
                .type(RestParamType.query)
                .description("Netsuite Order Id")
                .required(true)
                .endParam()
                .param()
                .name("billingScheduleNetsuiteIds")
                .type(RestParamType.query)
                .description("Netsuite BillingSchedule Ids to be deleted separated by commas")
                .required(true)
                .endParam()
                .param()
                .name("billingScheduleDetailNetsuiteIds")
                .type(RestParamType.query)
                .description("Netsuite BillingScheduleDetail Ids to be deleted separated by commas")
                .required(false)
                .endParam()
                .to("direct:deleteOrder");

        from("direct:createOrder")
                .log("Creating order with body=${body}")
                .setBody(constant("{\"status\": \"success\", \"message\": \"Order created successfully\"}"))
                .setHeader("Content-Type", constant("application/json"));

        from("direct:updateOrder")
                .log("Updating order with body=${body}")
                .setBody(constant("{\"status\": \"success\", \"message\": \"Order updated successfully\"}"))
                .setHeader("Content-Type", constant("application/json"));

        from("direct:deleteOrder")
                .log("Deleting order with orderNetsuiteId=${header.orderNetsuiteId}, billingScheduleNetsuiteIds=${header.billingScheduleNetsuiteIds}, billingScheduleDetailNetsuiteIds=${header.billingScheduleDetailNetsuiteIds}")
                .setBody(constant("{\"status\": \"success\", \"message\": \"Order deleted successfully\"}"))
                .setHeader("Content-Type", constant("application/json"));

        // Route for /invoices
        rest("/invoices")
                .put()
                .description("Request for updating invoice")
                .type(String.class)
                .to("direct:updateInvoice");

        from("direct:updateInvoice")
                .log("Updating invoice with body=${body}")
                .setBody(constant("{\"status\": \"success\", \"message\": \"Invoice updated successfully\"}"))
                .setHeader("Content-Type", constant("application/json"));
    }
}