package com._3degrees.orders.salesforce.exp.route;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;


@Component
public class CommonRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        getCamelContext().getGlobalOptions().put("CamelJacksonEnableTypeConverter", "true");

        // REST API
        restConfiguration().component("servlet");

        from("direct:rest")
                .routeId("direct-rest")
                .toD("${exchangeProperty.serviceUrl}")
                .removeProperty("serviceUrl")
                .removeHeader(Exchange.HTTP_METHOD);

    }
}
