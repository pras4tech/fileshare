package com._3degrees.orders.salesforce.exp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class expApplicationTests {

	@Test
	void contextLoads() {
	}

}
