package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class OnSfOrderDeleteRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Error handling for data validation errors
        onException(Exception.class)
                .log("Data validation error occurred")
                .process(exchange -> {
                    String errorPayload = """
                    {
                      "errorMessage": "Data validation error",
                      "payload": ${exchange.getIn().getBody(String.class)}
                    }
                """;
                    exchange.getIn().setBody(errorPayload);
                    exchange.getIn().setHeader("httpStatus", 400);
                })
                .handled(true);
        // Main route for processing Salesforce order deletion
        from("direct:pf-on-sf-order-delete")
            .routeId("pfOnSfOrderDelete")
            .log("Flow Started: pf-on-sf-order-delete")
            .process(exchange -> {
                // Set headers and variables
                exchange.getIn().setHeader("correlationId", exchange.getProperty("vCorrelationId", String.class));
                exchange.getIn().setHeader("x-transactionId", exchange.getProperty("vTransactionId", String.class));
                exchange.getIn().setHeader("x-msg-timestamp", exchange.getProperty("vMsgTimestamp", String.class));
                exchange.getIn().setHeader("sourceId", "Salesforce-exp-api");
                exchange.getIn().setHeader("destinationId", "order-prc-api");
                exchange.getIn().setHeader("x-businessKey", "OrderNetsuiteId-" + exchange.getProperty("vBusinessKey", String.class));
            })
            .log("Log Outbound Request: Endpoint=${properties:https.request.orderPrcApi.orders.path}")
            .log("Log Outbound Request Payload: ${body}")
            .toD("http4://${properties:https.request.orderPrcApi.orders.path}?httpMethod=DELETE")
            .log("Log Outbound Response Payload: ${body}")
            .log("Flow Ended: pf-on-sf-order-delete");

        }
}