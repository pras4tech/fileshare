package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class OnSfProductCreatedRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .log("Exception occurred: ${exception.message}")
            .handled(true);

        // Main route for processing Salesforce product creation
        from("direct:pf-on-sf-product-created")
            .routeId("pfOnSfProductCreated")
            .log("Flow Started: pf-on-sf-product-created")
            .process(exchange -> {
                // Set headers and variables
                exchange.getIn().setHeader("correlationId", exchange.getProperty("vCorrelationId", String.class));
                exchange.getIn().setHeader("x-transactionId", exchange.getProperty("vTransactionId", String.class));
                exchange.getIn().setHeader("x-msg-timestamp", java.time.Instant.now().toString());
                exchange.getIn().setHeader("sourceId", "Salesforce-exp-api");
                exchange.getIn().setHeader("destinationId", "transaction-db-sys-api");
                exchange.getIn().setHeader("content-type", "application/json");
            })
            .choice()
                .when(PredicateBuilder.and(
                    simple("${header.typeOfProduct} == 'commodity' && ${properties:enableSyncForSalesforceCommodities} == '1'"),
                    simple("${header.typeOfProduct} == 'service' && ${properties:enableSyncForSalesforceServices} == '1'")
                ))
                    .log("enableSyncForSalesforce is enabled for ${header.typeOfProduct}")
                    .toD("direct:processProductSync")
                .otherwise()
                    .log("enableSyncForSalesforce is disabled for ${header.typeOfProduct}")
                    .process(exchange -> {
                        exchange.getIn().setBody("{ \"status\": \"IGNORED\", \"message\": \"Syncing is ignored as enableSyncForSalesforce is disabled\" }");
                    })
            .end()
            .log("Flow Ended: pf-on-sf-product-created");

        // Sub-route to process product sync
        from("direct:processProductSync")
            .routeId("processProductSync")
            .log("Processing product sync")
            .toD("http4://transaction-db-sys-api/api/REF_ID?httpMethod=POST")
            .process(exchange -> {
                // Set transaction details
                String transactionDetails = """
                    {
                        "transaction": {
                            "CORRELATION_ID": "${header.correlationId}",
                            "OPERATION": "CREATE",
                            "SOURCE": "SALESFORCE",
                            "STATUS": "QUEUED",
                            "LAST_UPDATED_BY": "EXPERIENCE_API",
                            "OBJECT_TYPE": "PRODUCT",
                            "PRIORITY": 0,
                            "RETRY_COUNT": 0
                        }
                    }
                """;
                exchange.getIn().setBody(transactionDetails);
            })
            .toD("http4://transaction-db-sys-api/api/TRANSACTION?httpMethod=POST")
            .toD("http4://sync-prc-api/syncProducts?httpMethod=GET")
            .log("Sync record response: ${body}");
    }
}