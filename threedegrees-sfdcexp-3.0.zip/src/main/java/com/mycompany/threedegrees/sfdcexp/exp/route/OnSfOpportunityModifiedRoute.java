package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class OnSfOpportunityModifiedRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .log("Exception occurred: ${exception.message}")
            .handled(true);

        // Main route for processing Salesforce opportunity modifications
        from("direct:pf-on-sf-opportunity-modified")
            .routeId("pfOnSfOpportunityModified")
            .log("Flow Started: pf-on-sf-opportunity-modified")
            .process(exchange -> {
                // Set headers and variables
                exchange.getIn().setHeader("correlationId", exchange.getProperty("vCorrelationId", String.class));
                exchange.getIn().setHeader("x-transactionId", exchange.getProperty("vTransactionId", String.class));
                exchange.getIn().setHeader("x-msg-timestamp", java.time.Instant.now().toString());
                exchange.getIn().setHeader("sourceId", "salesforce-exp-api");
                exchange.getIn().setHeader("destinationId", "order-prc-api");
                exchange.getIn().setHeader("x-businessKey", "OpportunitySalesforceId-" + exchange.getProperty("vBusinessKey", String.class));
            })
            .log("Log Outbound Request: Invoked via Salesforce trigger")
            .log("Log Outbound Request Payload: ${body}")
            .choice()
                .when(PredicateBuilder.and(
                    simple("${header.x-businessKey} != null"),
                    simple("${header.x-transactionId} != null")
                ))
                    .log("Processing Opportunity with HTTP Method: ${header.vRequestHTTPMethod}")
                    .toD("http4://${properties:https.request.orderPrcApi.opportunities.path}?httpMethod=${header.vRequestHTTPMethod}")
                .otherwise()
                    .log("Skipping processing due to missing headers")
            .end()
            .log("Log Outbound Response Payload: ${body}")
            .log("Flow Ended: pf-on-sf-opportunity-modified");
    }
}