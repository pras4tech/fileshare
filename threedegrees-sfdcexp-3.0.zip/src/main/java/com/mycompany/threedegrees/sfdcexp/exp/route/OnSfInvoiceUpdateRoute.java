package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class OnSfInvoiceUpdateRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Error handling for data validation errors
        onException(Exception.class)
                .log("Data validation error occurred")
                .process(exchange -> {
                    String errorPayload = """
                    {
                      "errorMessage": "Data validation error",
                      "payload": ${exchange.getIn().getBody(String.class)}
                    }
                """;
                    exchange.getIn().setBody(errorPayload);
                    exchange.getIn().setHeader("httpStatus", 400);
                })
                .handled(true);

        // Main route for processing Salesforce invoice updates
        from("direct:pf-on-sf-invoice-updated")
            .routeId("pfOnSfInvoiceUpdated")
            .log("Flow Started: pf-on-sf-invoice-updated")
            .process(exchange -> {
                // Set headers and variables
                exchange.getIn().setHeader("x-source", "salesforce-exp-api");
                exchange.getIn().setHeader("x-transactionId", exchange.getProperty("vTransactionId", String.class));
                exchange.getIn().setHeader("x-msg-timestamp", exchange.getProperty("vMsgTimestamp", String.class));
                exchange.getIn().setHeader("correlationId", exchange.getProperty("vCorrelationId", String.class));
                exchange.getIn().setHeader("sourceId", "salesforce-exp-api");
                exchange.getIn().setHeader("destinationId", "order-prc-api");
                exchange.getIn().setHeader("x-businessKey", "InvoiceNetsuiteId-" + exchange.getProperty("vBusinessKey", String.class));
            })
            .log("Log Outbound Request: Endpoint=${properties:https.request.orderPrcApi.invoices.path}")
            .log("Log Outbound Request Payload: ${body}")
            .process(exchange -> {
                // Set payload for order-prc API
                String payload = """
                    {
                      "invoice": {
                        "netSuiteInvoiceId": ${exchange.getIn().getBody(Map.class).get("invoiceNSId")},
                        "approvalStatus": ${exchange.getIn().getBody(Map.class).get("approvalStatus")},
                        "comments": ${exchange.getIn().getBody(Map.class).get("comments")},
                        "sfId": ${exchange.getIn().getBody(Map.class).get("invoiceSFId")}
                      }
                    }
                """;
                exchange.getIn().setBody(payload);
            })
            .toD("http4://${properties:https.request.orderPrcApi.invoices.path}?httpMethod=PUT")
            .log("Log Outbound Response Payload: ${body}")
            .log("Log Outbound Response: Endpoint=${properties:https.request.orderPrcApi.invoices.path}")
            .log("Flow Ended: pf-on-sf-invoice-updated");
    }
}