package com.mycompany.threedegrees.sfdcexp.exp.config;


import org.apache.camel.support.jsse.SSLContextParameters;
import org.apache.camel.support.jsse.KeyManagersParameters;
import org.apache.camel.support.jsse.KeyStoreParameters;
import org.apache.camel.support.jsse.TrustManagersParameters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SSLConfig {

    @Bean
    public SSLContextParameters sslContextParameters() {
        KeyStoreParameters keyStoreParameters = new KeyStoreParameters();
        keyStoreParameters.setResource("classpath:truststore-local.jks");
        keyStoreParameters.setPassword("mulesoft@789");

        KeyManagersParameters keyManagersParameters = new KeyManagersParameters();
        keyManagersParameters.setKeyStore(keyStoreParameters);
        keyManagersParameters.setKeyPassword("mulesoft@789");

        KeyStoreParameters trustStoreParameters = new KeyStoreParameters();
        trustStoreParameters.setResource("classpath:truststore-local.jks");
        trustStoreParameters.setPassword("mulesoft@789");

        TrustManagersParameters trustManagersParameters = new TrustManagersParameters();
        trustManagersParameters.setKeyStore(trustStoreParameters);

        SSLContextParameters sslContextParameters = new SSLContextParameters();
        sslContextParameters.setKeyManagers(keyManagersParameters);
        sslContextParameters.setTrustManagers(trustManagersParameters);

        return sslContextParameters;
    }
}
