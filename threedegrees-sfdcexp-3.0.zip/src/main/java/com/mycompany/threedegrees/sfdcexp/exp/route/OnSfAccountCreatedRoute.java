package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class OnSfAccountCreatedRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .log("Exception occurred: ${exception.message}")
            .handled(true);

        // Main route for processing Salesforce account creation
        from("direct:pf-on-sf-account-created")
            .routeId("pfOnSfAccountCreated")
            .log("Flow Started: pf-on-sf-account-created")
            .process(exchange -> {
                // Set headers and variables
                exchange.getIn().setHeader("x-source", "SALESFORCE");
                exchange.getIn().setHeader("x-transactionId", exchange.getProperty("vTransactionId", String.class));
                exchange.getIn().setHeader("x-msg-timestamp", java.time.Instant.now().toString());
                exchange.getIn().setHeader("correlationId", exchange.getProperty("vCorrelationId", String.class));
                exchange.getIn().setHeader("sourceId", "SALESFORCE_EXP_API");
                exchange.getIn().setHeader("destinationId", "TRANSACTION_DB_SYS_API");
                exchange.getIn().setHeader("content-type", "application/json");
            })
            .choice()
                .when(PredicateBuilder.and(
                    simple("${properties:enableSyncForSalesforce} == '1'"),
                    simple("${header.x-source} == 'SALESFORCE'")
                ))
                    .log("enableSyncForSalesforce is enabled")
                    .toD("direct:processAccountSync")
                .otherwise()
                    .log("enableSyncForSalesforce is disabled")
                    .process(exchange -> {
                        exchange.getIn().setBody("{ \"status\": \"IGNORED\", \"message\": \"Syncing is disabled\" }");
                    })
            .end()
            .log("Flow Ended: pf-on-sf-account-created");

        // Sub-route to process account sync
        from("direct:processAccountSync")
            .routeId("processAccountSync")
            .log("Processing account sync")
            .toD("http4://transaction-db-sys-api/REF_ID")
            .choice()
                .when(simple("${body} != null"))
                    .log("Record found in REF_ID table")
                    .toD("direct:insertTransactionDetails")
                .otherwise()
                    .log("Record does not exist in REF_ID table")
                    .process(exchange -> {
                        exchange.getIn().setBody("{ \"status\": \"SUCCESS\", \"message\": \"Record not found in REF_ID table\" }");
                    })
            .end();

        // Sub-route to insert transaction details
        from("direct:insertTransactionDetails")
            .routeId("insertTransactionDetails")
            .log("Inserting into TRANSACTION_DETAIL")
            .process(exchange -> {
                String correlationId = exchange.getProperty("vCorrelationId", String.class);
                String transactionDetails = "{ \"CORRELATION_ID\": \"" + correlationId + "\", \"OPERATION\": \"CREATE\" }";
                exchange.getIn().setBody(transactionDetails);
            })
            .toD("http4://transaction-db-sys-api/TRANSACTION")
            .toD("direct:callSyncPrc");

        // Sub-route to call SyncPrc
        from("direct:callSyncPrc")
            .routeId("callSyncPrc")
            .log("Calling SyncPrc to process record")
            .setHeader("correlationId", simple("${header.correlationId}"))
            .toD("http4://sync-prc-api/syncRecords")
            .log("Sync record response: ${body}");
    }
}