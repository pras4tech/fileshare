namespace SalesforceExpApi.Infrastructure.HttpClients.Interfaces
{
    public interface ISyncPrcApiClient
    {
        Task<object> SyncRecordsAsync(string correlationId);
        Task<object> SyncProductsAsync(string correlationId);
    }
}
