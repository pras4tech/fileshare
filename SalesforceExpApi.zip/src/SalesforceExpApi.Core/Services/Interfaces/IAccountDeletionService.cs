using SalesforceExpApi.Core.Models.Responses;

namespace SalesforceExpApi.Core.Services.Interfaces
{
    public interface IAccountDeletionService
    {
        Task<NotifyDeleteResponse> ProcessAccountDeletionAsync(string id, string objectType, string updatedBy, int? syncPriority, string correlationId);
    }
}
