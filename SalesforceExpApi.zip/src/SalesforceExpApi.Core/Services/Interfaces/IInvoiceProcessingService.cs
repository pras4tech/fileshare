using SalesforceExpApi.Core.Models.Requests;
using SalesforceExpApi.Core.Models.Responses;

namespace SalesforceExpApi.Core.Services.Interfaces
{
    public interface IInvoiceProcessingService
    {
        Task<UpdateInvoiceResponse> UpdateInvoiceAsync(UpdateInvoiceRequest request, string correlationId, string transactionId, string businessKey);
    }
}
