using System.ComponentModel.DataAnnotations;
using SalesforceExpApi.Core.Models.Domain;

namespace SalesforceExpApi.Core.Models.Requests
{
    public class UpdateOrderRequest
    {
        [Required]
        public Order Order { get; set; } = new();
    }
}
