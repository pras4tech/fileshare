using System.ComponentModel.DataAnnotations;
using SalesforceExpApi.Core.Models.Domain;

namespace SalesforceExpApi.Core.Models.Requests
{
    public class UpdateInvoiceRequest
    {
        [Required]
        public Invoice Invoice { get; set; } = new();
    }
}
