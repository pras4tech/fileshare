namespace SalesforceExpApi.Core.Models.Common
{
    public abstract class BaseResponse
    {
        public int Code { get; set; }
        public string Status { get; set; } = string.Empty;
        public string TransactionId { get; set; } = string.Empty;
    }

    public class SuccessResponse<T> : BaseResponse
    {
        public T Response { get; set; } = default!;
    }
}
