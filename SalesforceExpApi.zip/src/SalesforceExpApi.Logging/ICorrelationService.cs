namespace SalesforceExpApi.Logging
{
    /// <summary>
    /// Correlation ID service for tracking requests
    /// </summary>
    public interface ICorrelationService
    {
        string GetCorrelationId();
        string GetTransactionId();
        void SetCorrelationId(string correlationId);
        void SetTransactionId(string transactionId);
    }
}
