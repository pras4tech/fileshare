package com.mycompany.threedegrees.sfdcexp.exp.route;

import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class SalesforceExpAPIRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .log("Exception occurred: ${exception.message}")
            .handled(true);

        // REST configuration using servlet
        restConfiguration()
            .component("servlet")
            .contextPath("camel")
            .enableCORS(true);

        // REST endpoints
        rest("/api")
            .get("/notifyDelete")
                .to("direct:pf-notify-sf-account-delete")
            .put("/invoices")
                .to("direct:pf-on-sf-invoice-update")
            .put("/orders")
                .to("direct:pf-on-sf-order-update")
            .delete("/orders")
                .to("direct:pf-on-sf-order-delete")
            .patch("/orders")
                .to("direct:pf-on-sf-order-patch");

        // Sub-route for notifyDelete - commented as it is implemented in other file
        /*from("direct:pf-notify-sf-account-delete")
            .routeId("pfNotifySfAccountDelete")
            .log("Processing notifyDelete request")
            .process(exchange -> {
                // Placeholder for notifyDelete logic
                log.info("Account deletion notification processed successfully");
            });*/

        // Sub-route for invoice update
        from("direct:pf-on-sf-invoice-update")
            .routeId("pfOnSfInvoiceUpdate")
            .log("Processing invoice update")
            .process(exchange -> {
                // Placeholder for invoice update logic
                log.info("Invoice updated successfully");
            });

        // Sub-route for order update
        from("direct:pf-on-sf-order-update")
            .routeId("pfOnSfOrderUpdate")
            .log("Processing order update")
            .process(exchange -> {
                // Placeholder for order update logic
                log.info("Order updated successfully");
            });

        // Sub-route for order deletion
        from("direct:pf-on-sf-order-delete")
            .routeId("pfOnSfOrderDelete")
            .log("Processing order deletion")
            .process(exchange -> {
                // Placeholder for order deletion logic
                log.info("Order deleted successfully");
            });

        // Sub-route for order patch
        from("direct:pf-on-sf-order-patch")
            .routeId("pfOnSfOrderPatch")
            .log("Processing order patch")
            .process(exchange -> {
                // Placeholder for order patch logic
                log.info("Order patched successfully");
            });
    }
}